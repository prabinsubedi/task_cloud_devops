import boto3
import json
import os 
def handler(event, context):
  path = event['path']
  request = event['httpMethod']
  bucket = os.environ.get('bucket')
  region = os.environ.get('region')
  s3 = boto3.client('s3', region)
  paginator = s3.get_paginator("list_objects_v2")
  pages = paginator.paginate(Bucket=bucket)
  objectNameList = []
  objectSizeList = [] 
  dictObjectNameSize = {} 
  if path == "/lambda/get-objects" and request=="GET":
    for page in pages:
      for object in page['Contents']:
        objectNameList.append(object['Key'])
        objectSizeList.append(object['Size'])
    dictObjectNameSize = {key: value for key, value in zip(objectNameList, objectSizeList)}
    response = {
      "statusCode": 200,
      "statusDescription": "200 OK",
      "isBase64Encoded": False,
      "headers": {
      "Content-Type": "application/json; charset=utf-8"
        },
      "body": json.dumps(dictObjectNameSize, default=str)
      }
    return response
